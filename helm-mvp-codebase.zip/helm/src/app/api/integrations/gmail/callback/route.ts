// src/app/api/integrations/gmail/callback/route.ts

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { db } from "@/lib/db";
import { encrypt } from "@/lib/crypto";
import { exchangeGmailCode } from "@/lib/integrations/gmail";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get("code");
  const orgId = searchParams.get("state"); // we passed orgId as state
  const error = searchParams.get("error");

  if (error) {
    return NextResponse.redirect(
      new URL(`/connect?error=${error}`, request.url)
    );
  }

  if (!code || !orgId) {
    return NextResponse.redirect(new URL("/connect?error=invalid", request.url));
  }

  try {
    const tokens = await exchangeGmailCode(code);

    if (!tokens.access_token) {
      throw new Error("No access token received");
    }

    // Store encrypted tokens in DB
    await db.integration.upsert({
      where: { orgId_type: { orgId, type: "GMAIL" } },
      update: {
        accessTokenEncrypted: encrypt(tokens.access_token),
        refreshTokenEncrypted: tokens.refresh_token
          ? encrypt(tokens.refresh_token)
          : undefined,
        tokenExpiresAt: tokens.expiry_date
          ? new Date(tokens.expiry_date)
          : null,
        status: "ACTIVE",
        syncError: null,
      },
      create: {
        orgId,
        type: "GMAIL",
        status: "ACTIVE",
        accessTokenEncrypted: encrypt(tokens.access_token),
        refreshTokenEncrypted: tokens.refresh_token
          ? encrypt(tokens.refresh_token)
          : null,
        tokenExpiresAt: tokens.expiry_date
          ? new Date(tokens.expiry_date)
          : null,
      },
    });

    // Redirect to dashboard with success message
    return NextResponse.redirect(
      new URL("/connect?success=gmail", request.url)
    );
  } catch (err) {
    console.error("Gmail OAuth error:", err);
    return NextResponse.redirect(
      new URL("/connect?error=gmail_failed", request.url)
    );
  }
}
