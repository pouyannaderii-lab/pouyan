// src/app/api/integrations/gmail/route.ts
// Handles Gmail OAuth flow: initiate + callback

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { db } from "@/lib/db";
import { encrypt } from "@/lib/crypto";
import { getGmailAuthUrl, exchangeGmailCode } from "@/lib/integrations/gmail";

// GET /api/integrations/gmail — initiate OAuth
export async function GET(request: NextRequest) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  const dbUser = await db.user.findUnique({ where: { supabaseId: user.id } });
  if (!dbUser) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  const authUrl = getGmailAuthUrl(dbUser.orgId);
  return NextResponse.redirect(authUrl);
}

// GET /api/integrations/gmail/callback — handle OAuth callback
export async function POST(request: NextRequest) {
  // This is handled by the callback route below
}
