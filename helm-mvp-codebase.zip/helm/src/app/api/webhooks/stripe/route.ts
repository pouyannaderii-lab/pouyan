// src/app/api/webhooks/stripe/route.ts
// Handles Stripe webhook events for subscription lifecycle management
// Webhooks are how Stripe tells us when subscriptions change

import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { db } from "@/lib/db";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-02-15",
});

export async function POST(request: NextRequest) {
  const body = await request.text();
  const signature = request.headers.get("stripe-signature")!;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error("Stripe webhook signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  console.log(`[webhook] Stripe event: ${event.type}`);

  try {
    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdate(subscription);
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionCancelled(subscription);
        break;
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object as Stripe.Invoice;
        console.log(`[webhook] Payment succeeded for invoice: ${invoice.id}`);
        break;
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        await handlePaymentFailed(invoice);
        break;
      }

      default:
        console.log(`[webhook] Unhandled event type: ${event.type}`);
    }
  } catch (err) {
    console.error(`[webhook] Error handling ${event.type}:`, err);
    return NextResponse.json(
      { error: "Webhook handler error" },
      { status: 500 }
    );
  }

  return NextResponse.json({ received: true });
}

async function handleSubscriptionUpdate(subscription: Stripe.Subscription) {
  const customerId = subscription.customer as string;

  const org = await db.organization.findUnique({
    where: { stripeCustomerId: customerId },
  });

  if (!org) {
    console.error(`[webhook] Org not found for customer: ${customerId}`);
    return;
  }

  // Map Stripe price to plan
  const priceId = subscription.items.data[0]?.price?.id;
  const plan = mapPriceToPlan(priceId);

  await db.organization.update({
    where: { id: org.id },
    data: {
      plan,
      stripeSubscriptionId: subscription.id,
      planExpiresAt:
        subscription.status === "active"
          ? new Date(subscription.current_period_end * 1000)
          : null,
    },
  });

  console.log(`[webhook] Updated org ${org.id} to plan: ${plan}`);
}

async function handleSubscriptionCancelled(subscription: Stripe.Subscription) {
  const customerId = subscription.customer as string;

  await db.organization.updateMany({
    where: { stripeCustomerId: customerId },
    data: {
      plan: "TRIAL",
      planExpiresAt: new Date(), // Expired immediately
    },
  });
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  // Email the org owner about failed payment
  // In MVP: just log it. Later: send dunning email via Resend
  console.log(`[webhook] Payment failed for customer: ${invoice.customer}`);
}

function mapPriceToPlan(priceId: string | undefined): "TRIAL" | "STARTER" | "GROWTH" | "SCALE" {
  const priceMap: Record<string, "STARTER" | "GROWTH" | "SCALE"> = {
    [process.env.STRIPE_STARTER_PRICE_ID || ""]: "STARTER",
    [process.env.STRIPE_GROWTH_PRICE_ID || ""]: "GROWTH",
    [process.env.STRIPE_SCALE_PRICE_ID || ""]: "SCALE",
  };
  return priceId ? (priceMap[priceId] || "STARTER") : "TRIAL";
}
