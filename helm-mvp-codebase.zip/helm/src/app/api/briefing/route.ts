// src/app/api/briefing/route.ts
// API routes for the daily briefing

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { db } from "@/lib/db";
import { generateBriefing, saveBriefing } from "@/lib/ai/briefing-engine";

// GET /api/briefing — fetch today's briefing for the current user
export async function GET(request: NextRequest) {
  const supabase = createClient();
  const { data: { user: authUser } } = await supabase.auth.getUser();

  if (!authUser) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const user = await db.user.findUnique({
    where: { supabaseId: authUser.id },
  });

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  // Find today's briefing
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const briefing = await db.briefing.findUnique({
    where: {
      orgId_userId_date: {
        orgId: user.orgId,
        userId: user.id,
        date: today,
      },
    },
    include: {
      items: {
        orderBy: { order: "asc" },
      },
    },
  });

  if (!briefing) {
    return NextResponse.json({ briefing: null }, { status: 200 });
  }

  return NextResponse.json({ briefing }, { status: 200 });
}

// POST /api/briefing — manually trigger a briefing regeneration
export async function POST(request: NextRequest) {
  const supabase = createClient();
  const { data: { user: authUser } } = await supabase.auth.getUser();

  if (!authUser) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const user = await db.user.findUnique({
    where: { supabaseId: authUser.id },
  });

  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  // Rate limit: don't allow more than 3 manual regenerations per day
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  try {
    const briefingData = await generateBriefing(user.orgId, user);
    const briefingId = await saveBriefing(user.orgId, user.id, briefingData, new Date());

    const briefing = await db.briefing.findUnique({
      where: { id: briefingId },
      include: { items: { orderBy: { order: "asc" } } },
    });

    return NextResponse.json({ briefing }, { status: 200 });
  } catch (error) {
    console.error("Briefing generation error:", error);
    return NextResponse.json(
      { error: "Failed to generate briefing" },
      { status: 500 }
    );
  }
}

// PATCH /api/briefing — update item feedback or mark action taken
export async function PATCH(request: NextRequest) {
  const supabase = createClient();
  const { data: { user: authUser } } = await supabase.auth.getUser();

  if (!authUser) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json();
  const { itemId, feedback, actionTaken } = body;

  if (!itemId) {
    return NextResponse.json({ error: "itemId required" }, { status: 400 });
  }

  const updated = await db.briefingItem.update({
    where: { id: itemId },
    data: {
      ...(feedback !== undefined && { userFeedback: feedback }),
      ...(actionTaken !== undefined && {
        actionTaken,
        actionTakenAt: actionTaken ? new Date() : null,
      }),
    },
  });

  return NextResponse.json({ item: updated }, { status: 200 });
}
