// src/workers/nightly-briefing.ts
// ─────────────────────────────────────────
// HELM NIGHTLY BRIEFING WORKER
// Runs as a standalone Node.js process (not Next.js)
// Start with: npm run worker:briefing
//
// Schedule: checks every 5 minutes, runs briefing for each user
// at their configured briefingTime in their timezone.
// ─────────────────────────────────────────

import { Queue, Worker, Job } from "bullmq";
import IORedis from "ioredis";
import { db } from "@/lib/db";
import { generateBriefing, saveBriefing } from "@/lib/ai/briefing-engine";
import { syncGmailEvents } from "@/lib/integrations/gmail";
import { syncStripeEvents } from "@/lib/integrations/stripe";
import { syncHubSpotEvents } from "@/lib/integrations/hubspot";
import { sendBriefingEmail } from "@/lib/email/send";

// ─────────────────────────────────────────
// REDIS CONNECTION
// ─────────────────────────────────────────

const connection = new IORedis(process.env.REDIS_URL!, {
  maxRetriesPerRequest: null, // required for BullMQ
  enableReadyCheck: false,
});

// ─────────────────────────────────────────
// QUEUES
// ─────────────────────────────────────────

// Queue 1: Sync data from all integrations for an org
export const syncQueue = new Queue("helm:sync", {
  connection,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: "exponential", delay: 2000 },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

// Queue 2: Generate and deliver the briefing for a user
export const briefingQueue = new Queue("helm:briefing", {
  connection,
  defaultJobOptions: {
    attempts: 2,
    backoff: { type: "fixed", delay: 5000 },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

// ─────────────────────────────────────────
// JOB TYPES
// ─────────────────────────────────────────

interface SyncJobData {
  orgId: string;
}

interface BriefingJobData {
  orgId: string;
  userId: string;
}

// ─────────────────────────────────────────
// WORKER 1: SYNC INTEGRATIONS
// ─────────────────────────────────────────

const syncWorker = new Worker<SyncJobData>(
  "helm:sync",
  async (job: Job<SyncJobData>) => {
    const { orgId } = job.data;
    console.log(`[sync] Starting data sync for org: ${orgId}`);

    const integrations = await db.integration.findMany({
      where: { orgId, status: "ACTIVE" },
    });

    const syncPromises = integrations.map(async (integration) => {
      try {
        switch (integration.type) {
          case "GMAIL":
            await syncGmailEvents(orgId, integration);
            console.log(`[sync] Gmail synced for org: ${orgId}`);
            break;
          case "STRIPE":
            await syncStripeEvents(orgId, integration);
            console.log(`[sync] Stripe synced for org: ${orgId}`);
            break;
          case "HUBSPOT":
            await syncHubSpotEvents(orgId, integration);
            console.log(`[sync] HubSpot synced for org: ${orgId}`);
            break;
          default:
            console.log(`[sync] Skipping unimplemented: ${integration.type}`);
        }
      } catch (err) {
        console.error(`[sync] Error syncing ${integration.type}:`, err);
        // Mark integration as error but don't fail the whole job
        await db.integration.update({
          where: { id: integration.id },
          data: {
            syncError: err instanceof Error ? err.message : "Unknown error",
          },
        });
      }
    });

    await Promise.allSettled(syncPromises);
    console.log(`[sync] Completed for org: ${orgId}`);
  },
  {
    connection,
    concurrency: 5, // Process up to 5 orgs simultaneously
  }
);

// ─────────────────────────────────────────
// WORKER 2: GENERATE & DELIVER BRIEFING
// ─────────────────────────────────────────

const briefingWorker = new Worker<BriefingJobData>(
  "helm:briefing",
  async (job: Job<BriefingJobData>) => {
    const { orgId, userId } = job.data;
    console.log(`[briefing] Generating briefing for user: ${userId}`);

    const user = await db.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new Error(`User not found: ${userId}`);
    }

    if (!user.briefingEnabled) {
      console.log(`[briefing] Briefings disabled for user: ${userId}, skipping`);
      return;
    }

    // Generate briefing using AI engine
    const briefingData = await generateBriefing(orgId, user);

    // Save to database
    const briefingId = await saveBriefing(orgId, userId, briefingData, new Date());
    console.log(`[briefing] Saved briefing: ${briefingId}`);

    // Send email if enabled
    if (user.emailBriefing) {
      const briefing = await db.briefing.findUnique({
        where: { id: briefingId },
        include: { items: { orderBy: { order: "asc" } } },
      });

      if (briefing) {
        await sendBriefingEmail(user, briefing);
        console.log(`[briefing] Email sent to: ${user.email}`);
      }
    }

    console.log(`[briefing] Complete for user: ${userId}`);
  },
  {
    connection,
    concurrency: 10,
  }
);

// ─────────────────────────────────────────
// SCHEDULER: QUEUE JOBS AT RIGHT TIME
// ─────────────────────────────────────────

/**
 * Check every 5 minutes: which users should get their briefing now?
 * This is timezone-aware — each user gets their briefing at THEIR 7am
 */
async function scheduleBriefings() {
  const now = new Date();

  const users = await db.user.findMany({
    where: { briefingEnabled: true },
    include: { org: { select: { plan: true } } },
  });

  for (const user of users) {
    // Convert "now" to user's timezone
    const userNow = new Date(
      now.toLocaleString("en-US", { timeZone: user.timezone })
    );
    const [targetHour, targetMinute] = user.briefingTime.split(":").map(Number);

    // Check if we're within the 5-minute window for this user's briefing time
    const isTime =
      userNow.getHours() === targetHour &&
      userNow.getMinutes() >= targetMinute &&
      userNow.getMinutes() < targetMinute + 5;

    if (!isTime) continue;

    // Check if we already ran today for this user (prevent double-send)
    const today = new Date(userNow);
    today.setHours(0, 0, 0, 0);

    const existingBriefing = await db.briefing.findUnique({
      where: {
        orgId_userId_date: {
          orgId: user.orgId,
          userId: user.id,
          date: today,
        },
      },
    });

    if (existingBriefing) {
      continue; // Already ran today
    }

    console.log(
      `[scheduler] Queuing briefing for ${user.email} (${user.timezone})`
    );

    // First sync data, then generate briefing
    // The briefing job will wait for sync to complete via delay
    await syncQueue.add(
      "sync-org",
      { orgId: user.orgId },
      { jobId: `sync-${user.orgId}-${today.toDateString()}` } // dedupe by org+day
    );

    await briefingQueue.add(
      "generate-briefing",
      { orgId: user.orgId, userId: user.id },
      {
        delay: 3 * 60 * 1000, // Wait 3 minutes for sync to complete
        jobId: `briefing-${user.id}-${today.toDateString()}`,
      }
    );
  }
}

// ─────────────────────────────────────────
// ERROR HANDLING
// ─────────────────────────────────────────

syncWorker.on("failed", (job, err) => {
  console.error(`[sync] Job ${job?.id} failed:`, err.message);
});

briefingWorker.on("failed", (job, err) => {
  console.error(`[briefing] Job ${job?.id} failed:`, err.message);
});

syncWorker.on("completed", (job) => {
  console.log(`[sync] Job ${job.id} completed`);
});

briefingWorker.on("completed", (job) => {
  console.log(`[briefing] Job ${job.id} completed`);
});

// ─────────────────────────────────────────
// START
// ─────────────────────────────────────────

console.log("🚀 Helm workers starting...");
console.log("📊 Sync worker: ready");
console.log("🧠 Briefing worker: ready");
console.log("⏰ Scheduler: checking every 5 minutes");

// Run scheduler immediately, then every 5 minutes
scheduleBriefings().catch(console.error);
setInterval(() => {
  scheduleBriefings().catch(console.error);
}, 5 * 60 * 1000);

// Keep process alive
process.on("SIGTERM", async () => {
  console.log("Shutting down workers...");
  await syncWorker.close();
  await briefingWorker.close();
  await connection.quit();
  process.exit(0);
});
