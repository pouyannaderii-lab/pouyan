// src/lib/integrations/stripe.ts
// Stripe Integration — MRR, overdue invoices, failed charges, churn signals
// Uses read-only Stripe key (sk_live_... with restricted permissions)

import Stripe from "stripe";
import { decrypt } from "@/lib/crypto";
import { db } from "@/lib/db";
import { fingerprint } from "@/lib/crypto";
import type { Integration } from "@prisma/client";

function getStripeClient(integration: Integration): Stripe {
  const secretKey = decrypt(integration.accessTokenEncrypted);
  return new Stripe(secretKey, { apiVersion: "2024-02-15" });
}

// ─────────────────────────────────────────
// METRICS
// ─────────────────────────────────────────

export interface StripeMetrics {
  mrr: number;               // Monthly Recurring Revenue in cents
  totalOutstanding: number;  // Total unpaid invoice amount in cents
  overdueInvoices: OverdueInvoice[];
  failedCharges: FailedCharge[];
  churnedThisMonth: number;  // Count of cancelled subscriptions
  newMrrThisMonth: number;   // New subscriptions MRR added this month
}

export interface OverdueInvoice {
  id: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  amount: number;            // in cents
  daysOverdue: number;
  invoiceUrl: string;
  reminderCount: number;     // how many Stripe auto-reminders sent
}

export interface FailedCharge {
  id: string;
  customerId: string;
  customerName: string;
  amount: number;
  failureReason: string;
  occurredAt: Date;
}

/**
 * Calculate MRR from active subscriptions
 */
export async function getMRR(integration: Integration): Promise<number> {
  const stripe = getStripeClient(integration);
  let mrr = 0;

  const subscriptions = await stripe.subscriptions.list({
    status: "active",
    expand: ["data.items.data.price"],
    limit: 100,
  });

  for (const sub of subscriptions.data) {
    for (const item of sub.items.data) {
      const price = item.price;
      const amount = price.unit_amount || 0;

      // Normalize to monthly
      if (price.recurring?.interval === "month") {
        mrr += amount * (item.quantity || 1);
      } else if (price.recurring?.interval === "year") {
        mrr += Math.round((amount / 12) * (item.quantity || 1));
      } else if (price.recurring?.interval === "week") {
        mrr += Math.round(amount * 4.33 * (item.quantity || 1));
      }
    }
  }

  return mrr; // in cents
}

/**
 * Find overdue invoices (past due, not paid)
 */
export async function getOverdueInvoices(
  integration: Integration
): Promise<OverdueInvoice[]> {
  const stripe = getStripeClient(integration);
  const overdue: OverdueInvoice[] = [];

  const invoices = await stripe.invoices.list({
    status: "open",
    limit: 100,
    expand: ["data.customer"],
  });

  for (const invoice of invoices.data) {
    if (!invoice.due_date) continue;
    const dueDate = new Date(invoice.due_date * 1000);
    const daysOverdue = Math.floor(
      (Date.now() - dueDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (daysOverdue > 0) {
      const customer = invoice.customer as Stripe.Customer;
      overdue.push({
        id: invoice.id,
        customerId: customer.id,
        customerName: customer.name || "Unknown",
        customerEmail: customer.email || "",
        amount: invoice.amount_due,
        daysOverdue,
        invoiceUrl: invoice.hosted_invoice_url || "",
        reminderCount: (invoice.metadata?.reminder_count as any) || 0,
      });
    }
  }

  return overdue.sort((a, b) => b.daysOverdue - a.daysOverdue);
}

/**
 * Find failed payment charges in the last 7 days
 */
export async function getFailedCharges(
  integration: Integration
): Promise<FailedCharge[]> {
  const stripe = getStripeClient(integration);
  const sevenDaysAgo = Math.floor(Date.now() / 1000) - 7 * 24 * 60 * 60;

  const charges = await stripe.charges.list({
    created: { gte: sevenDaysAgo },
    limit: 100,
  });

  const failed: FailedCharge[] = [];

  for (const charge of charges.data) {
    if (charge.status === "failed") {
      // Get customer info
      let customerName = "Unknown";
      if (charge.customer) {
        try {
          const customer = await stripe.customers.retrieve(
            charge.customer as string
          );
          customerName = (customer as Stripe.Customer).name || "Unknown";
        } catch {}
      }

      failed.push({
        id: charge.id,
        customerId: charge.customer as string,
        customerName,
        amount: charge.amount,
        failureReason: charge.failure_message || "Unknown reason",
        occurredAt: new Date(charge.created * 1000),
      });
    }
  }

  return failed;
}

/**
 * Main sync function — extract all Stripe events and store in DB
 */
export async function syncStripeEvents(
  orgId: string,
  integration: Integration
): Promise<void> {
  const stripe = getStripeClient(integration);
  const [mrr, overdueInvoices, failedCharges] = await Promise.all([
    getMRR(integration),
    getOverdueInvoices(integration),
    getFailedCharges(integration),
  ]);

  const events = [];

  // Store MRR as baseline
  await db.businessBaseline.upsert({
    where: { orgId_metric: { orgId, metric: "mrr_cents" } },
    update: { value: mrr },
    create: { orgId, metric: "mrr_cents", value: mrr },
  });

  // Total outstanding
  const totalOutstanding = overdueInvoices.reduce((s, i) => s + i.amount, 0);
  if (totalOutstanding > 0) {
    const fp = fingerprint("stripe", "outstanding", orgId, new Date().toDateString());
    events.push({
      orgId,
      source: "STRIPE" as const,
      eventType: "invoice.outstanding_summary",
      severity: totalOutstanding > 5000000 ? ("CRITICAL" as const) : ("WARNING" as const),
      title: `$${(totalOutstanding / 100).toLocaleString()} outstanding across ${overdueInvoices.length} invoice${overdueInvoices.length !== 1 ? "s" : ""}`,
      description: `Oldest: ${overdueInvoices[0]?.daysOverdue} days overdue from ${overdueInvoices[0]?.customerName}. Total cash at risk: $${(totalOutstanding / 100).toLocaleString()}.`,
      amount: totalOutstanding / 100,
      rawData: overdueInvoices as any,
      fingerprint: fp,
    });
  }

  // Individual critical invoices (45+ days)
  for (const inv of overdueInvoices.filter((i) => i.daysOverdue >= 45)) {
    const fp = fingerprint("stripe", "overdue-critical", inv.id);
    events.push({
      orgId,
      source: "STRIPE" as const,
      eventType: "invoice.critically_overdue",
      severity: "CRITICAL" as const,
      title: `${inv.customerName} — $${(inv.amount / 100).toLocaleString()} invoice ${inv.daysOverdue} days overdue`,
      description: `Invoice ${inv.id} is ${inv.daysOverdue} days past due. ${inv.reminderCount} automated reminders sent. Manual intervention needed.`,
      amount: inv.amount / 100,
      entityId: inv.id,
      entityName: inv.customerName,
      entityUrl: inv.invoiceUrl,
      rawData: inv as any,
      fingerprint: fp,
    });
  }

  // Failed charges
  for (const charge of failedCharges) {
    const fp = fingerprint("stripe", "failed-charge", charge.id);
    events.push({
      orgId,
      source: "STRIPE" as const,
      eventType: "charge.failed",
      severity: "WARNING" as const,
      title: `Failed charge — ${charge.customerName} ($${(charge.amount / 100).toLocaleString()})`,
      description: `Payment failed: ${charge.failureReason}. Customer may need to update payment method.`,
      amount: charge.amount / 100,
      entityId: charge.customerId,
      entityName: charge.customerName,
      rawData: charge as any,
      fingerprint: fp,
      occurredAt: charge.occurredAt,
    });
  }

  // Upsert all events
  for (const event of events) {
    await db.businessEvent.upsert({
      where: { fingerprint: event.fingerprint },
      update: { description: event.description, amount: event.amount },
      create: event,
    });
  }

  await db.integration.update({
    where: { id: integration.id },
    data: { lastSyncAt: new Date(), syncError: null },
  });
}
