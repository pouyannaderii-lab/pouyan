// src/lib/integrations/gmail.ts
// Gmail Integration — reads emails to detect cold deals, unanswered threads
// Uses read-only OAuth scope: https://www.googleapis.com/auth/gmail.readonly

import { google } from "googleapis";
import { decrypt } from "@/lib/crypto";
import { db } from "@/lib/db";
import type { Integration, BusinessEvent } from "@prisma/client";
import { fingerprint } from "@/lib/crypto";

const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);

/** Get an authenticated Gmail client for a given integration */
export async function getGmailClient(integration: Integration) {
  const accessToken = decrypt(integration.accessTokenEncrypted);
  const refreshToken = integration.refreshTokenEncrypted
    ? decrypt(integration.refreshTokenEncrypted)
    : null;

  oauth2Client.setCredentials({
    access_token: accessToken,
    refresh_token: refreshToken,
  });

  // Auto-refresh token if expired
  if (integration.tokenExpiresAt && integration.tokenExpiresAt < new Date()) {
    const { credentials } = await oauth2Client.refreshAccessToken();
    // Update tokens in DB
    await db.integration.update({
      where: { id: integration.id },
      data: {
        accessTokenEncrypted: require("@/lib/crypto").encrypt(
          credentials.access_token!
        ),
        tokenExpiresAt: credentials.expiry_date
          ? new Date(credentials.expiry_date)
          : null,
      },
    });
    oauth2Client.setCredentials(credentials);
  }

  return google.gmail({ version: "v1", auth: oauth2Client });
}

/** Build OAuth URL for connecting Gmail */
export function getGmailAuthUrl(orgId: string): string {
  const scopes = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
  ];

  return oauth2Client.generateAuthUrl({
    access_type: "offline",
    scope: scopes,
    state: orgId, // passed back in callback
    prompt: "consent", // force refresh token
  });
}

/** Exchange auth code for tokens (called in /api/integrations/gmail/callback) */
export async function exchangeGmailCode(code: string) {
  const { tokens } = await oauth2Client.getToken(code);
  return tokens;
}

// ─────────────────────────────────────────
// DATA EXTRACTION
// ─────────────────────────────────────────

interface EmailThread {
  threadId: string;
  contactEmail: string;
  contactName: string;
  subject: string;
  lastMessageDate: Date;
  daysSinceReply: number;
  messageCount: number;
  snippet: string;
}

/**
 * Find email threads where WE sent the last email but got no reply
 * These are "cold" threads — potential deals going silent
 */
export async function findColdThreads(
  integration: Integration,
  dayThreshold = 7
): Promise<EmailThread[]> {
  const gmail = await getGmailClient(integration);
  const coldThreads: EmailThread[] = [];

  // Search for sent emails in the last 60 days
  const response = await gmail.users.threads.list({
    userId: "me",
    q: `in:sent after:${daysAgoQuery(60)} -in:drafts`,
    maxResults: 100,
  });

  if (!response.data.threads) return [];

  for (const thread of response.data.threads.slice(0, 50)) {
    // Rate limit: process max 50 threads
    if (!thread.id) continue;

    const threadData = await gmail.users.threads.get({
      userId: "me",
      id: thread.id,
      format: "metadata",
      metadataHeaders: ["From", "To", "Subject", "Date"],
    });

    const messages = threadData.data.messages || [];
    if (messages.length === 0) continue;

    const lastMessage = messages[messages.length - 1];
    const headers = lastMessage.payload?.headers || [];

    const fromHeader = headers.find((h) => h.name === "From")?.value || "";
    const toHeader = headers.find((h) => h.name === "To")?.value || "";
    const subject = headers.find((h) => h.name === "Subject")?.value || "";
    const dateStr = headers.find((h) => h.name === "Date")?.value || "";

    // Check if the last message is FROM us (we sent it, no reply)
    const myEmail = await getMyEmail(gmail);
    const lastMessageIsFromMe =
      fromHeader.includes(myEmail) || fromHeader.includes("me");

    if (!lastMessageIsFromMe) continue;

    const lastDate = new Date(dateStr);
    const daysSince = Math.floor(
      (Date.now() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (daysSince >= dayThreshold) {
      const contactEmail = extractEmail(toHeader);
      coldThreads.push({
        threadId: thread.id,
        contactEmail,
        contactName: extractName(toHeader),
        subject,
        lastMessageDate: lastDate,
        daysSinceReply: daysSince,
        messageCount: messages.length,
        snippet: threadData.data.snippet || "",
      });
    }
  }

  return coldThreads.sort((a, b) => b.daysSinceReply - a.daysSinceReply);
}

/**
 * Extract business events from Gmail and store in DB
 * Called by the nightly sync worker
 */
export async function syncGmailEvents(
  orgId: string,
  integration: Integration
): Promise<void> {
  const coldThreads = await findColdThreads(integration, 7);
  const events = [];

  for (const thread of coldThreads) {
    const severity = thread.daysSinceReply >= 14 ? "CRITICAL" : "WARNING";
    const fp = fingerprint("gmail", "cold-thread", thread.threadId);

    events.push({
      orgId,
      source: "GMAIL" as const,
      eventType: "email.cold_thread",
      severity: severity as any,
      title: `Cold email thread — ${thread.contactName || thread.contactEmail}`,
      description: `No reply in ${thread.daysSinceReply} days. Subject: "${thread.subject}". Thread has ${thread.messageCount} messages.`,
      entityId: thread.threadId,
      entityName: thread.contactName || thread.contactEmail,
      rawData: thread as any,
      fingerprint: fp,
      occurredAt: thread.lastMessageDate,
    });
  }

  // Upsert events (fingerprint prevents duplicates)
  for (const event of events) {
    await db.businessEvent.upsert({
      where: { fingerprint: event.fingerprint },
      update: {
        description: event.description,
        rawData: event.rawData,
      },
      create: event,
    });
  }

  // Update integration sync timestamp
  await db.integration.update({
    where: { id: integration.id },
    data: { lastSyncAt: new Date(), syncError: null },
  });
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────

let cachedMyEmail: string | null = null;

async function getMyEmail(gmail: any): Promise<string> {
  if (cachedMyEmail) return cachedMyEmail;
  const profile = await gmail.users.getProfile({ userId: "me" });
  cachedMyEmail = profile.data.emailAddress || "";
  return cachedMyEmail;
}

function extractEmail(header: string): string {
  const match = header.match(/<([^>]+)>/);
  return match ? match[1] : header.trim();
}

function extractName(header: string): string {
  const match = header.match(/^([^<]+)</);
  return match ? match[1].trim().replace(/"/g, "") : "";
}

function daysAgoQuery(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`;
}
