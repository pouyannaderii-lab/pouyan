// src/lib/integrations/hubspot.ts
// HubSpot Integration — CRM deals, pipeline health, contact engagement
// OAuth scopes: crm.objects.deals.read, crm.objects.contacts.read

import { db } from "@/lib/db";
import { decrypt } from "@/lib/crypto";
import { fingerprint } from "@/lib/crypto";
import type { Integration } from "@prisma/client";

const HUBSPOT_API = "https://api.hubapi.com";

async function hubspotFetch(
  integration: Integration,
  path: string,
  options: RequestInit = {}
) {
  const accessToken = decrypt(integration.accessTokenEncrypted);

  // Check if token needs refresh
  if (integration.tokenExpiresAt && integration.tokenExpiresAt < new Date()) {
    await refreshHubSpotToken(integration);
  }

  const res = await fetch(`${HUBSPOT_API}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  if (!res.ok) {
    const error = await res.text();
    throw new Error(`HubSpot API error ${res.status}: ${error}`);
  }

  return res.json();
}

async function refreshHubSpotToken(integration: Integration) {
  const refreshToken = decrypt(integration.refreshTokenEncrypted!);
  const res = await fetch("https://api.hubapi.com/oauth/v1/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      client_id: process.env.HUBSPOT_CLIENT_ID!,
      client_secret: process.env.HUBSPOT_CLIENT_SECRET!,
      refresh_token: refreshToken,
    }),
  });

  const tokens = await res.json();
  const { encrypt } = await import("@/lib/crypto");

  await db.integration.update({
    where: { id: integration.id },
    data: {
      accessTokenEncrypted: encrypt(tokens.access_token),
      tokenExpiresAt: new Date(Date.now() + tokens.expires_in * 1000),
    },
  });
}

// ─────────────────────────────────────────
// DEAL PIPELINE ANALYSIS
// ─────────────────────────────────────────

export interface Deal {
  id: string;
  name: string;
  amount: number;
  stage: string;
  closeDate: Date | null;
  lastActivityDate: Date | null;
  daysSinceActivity: number;
  ownerId: string;
  ownerName: string;
  probability: number;
}

export interface PipelineHealth {
  totalDeals: number;
  totalValue: number;
  coldDeals: Deal[];       // No activity > 14 days
  atRiskDeals: Deal[];     // Close date < 7 days, no recent activity
  weightedPipeline: number; // Sum of deal.amount * deal.probability
}

/**
 * Fetch all open deals and analyze pipeline health
 */
export async function getPipelineHealth(
  integration: Integration
): Promise<PipelineHealth> {
  const data = await hubspotFetch(
    integration,
    "/crm/v3/objects/deals?properties=dealname,amount,dealstage,closedate,hs_lastmodifieddate,hubspot_owner_id,hs_deal_stage_probability&limit=100&filterGroups[0][filters][0][propertyName]=dealstage&filterGroups[0][filters][0][operator]=NEQ&filterGroups[0][filters][0][value]=closedwon&filterGroups[0][filters][1][propertyName]=dealstage&filterGroups[0][filters][1][operator]=NEQ&filterGroups[0][filters][1][value]=closedlost"
  );

  const deals: Deal[] = (data.results || []).map((d: any) => {
    const lastActivity = d.properties.hs_lastmodifieddate
      ? new Date(d.properties.hs_lastmodifieddate)
      : null;
    const daysSince = lastActivity
      ? Math.floor((Date.now() - lastActivity.getTime()) / (1000 * 60 * 60 * 24))
      : 999;

    return {
      id: d.id,
      name: d.properties.dealname || "Unnamed Deal",
      amount: parseFloat(d.properties.amount || "0"),
      stage: d.properties.dealstage || "",
      closeDate: d.properties.closedate
        ? new Date(d.properties.closedate)
        : null,
      lastActivityDate: lastActivity,
      daysSinceActivity: daysSince,
      ownerId: d.properties.hubspot_owner_id || "",
      ownerName: "", // fetched separately if needed
      probability: parseFloat(d.properties.hs_deal_stage_probability || "0"),
    };
  });

  const now = new Date();
  const sevenDays = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  return {
    totalDeals: deals.length,
    totalValue: deals.reduce((s, d) => s + d.amount, 0),
    coldDeals: deals.filter((d) => d.daysSinceActivity >= 14),
    atRiskDeals: deals.filter(
      (d) =>
        d.closeDate &&
        d.closeDate <= sevenDays &&
        d.daysSinceActivity >= 5
    ),
    weightedPipeline: deals.reduce(
      (s, d) => s + d.amount * (d.probability / 100),
      0
    ),
  };
}

/**
 * Main sync — extract deal events into BusinessEvents
 */
export async function syncHubSpotEvents(
  orgId: string,
  integration: Integration
): Promise<void> {
  const pipeline = await getPipelineHealth(integration);
  const events = [];

  // Store baselines
  await db.businessBaseline.upsert({
    where: { orgId_metric: { orgId, metric: "pipeline_value" } },
    update: { value: pipeline.totalValue },
    create: { orgId, metric: "pipeline_value", value: pipeline.totalValue },
  });

  // Cold deals (no activity > 14 days)
  for (const deal of pipeline.coldDeals) {
    const fp = fingerprint("hubspot", "cold-deal", deal.id);
    const severity = deal.daysSinceActivity >= 21 ? "CRITICAL" : "WARNING";

    events.push({
      orgId,
      source: "HUBSPOT" as const,
      eventType: "deal.cold",
      severity: severity as any,
      title: `Deal going cold — ${deal.name}`,
      description: `No activity in ${deal.daysSinceActivity} days. Deal value: $${deal.amount.toLocaleString()}. Stage: ${deal.stage}. ${deal.closeDate ? `Close date: ${deal.closeDate.toLocaleDateString()}.` : ""}`,
      amount: deal.amount,
      entityId: deal.id,
      entityName: deal.name,
      entityUrl: `https://app.hubspot.com/contacts/deals/${deal.id}`,
      rawData: deal as any,
      fingerprint: fp,
    });
  }

  // At-risk deals (close date imminent, no activity)
  for (const deal of pipeline.atRiskDeals) {
    const fp = fingerprint("hubspot", "at-risk-deal", deal.id);
    const daysToClose = deal.closeDate
      ? Math.ceil((deal.closeDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
      : null;

    events.push({
      orgId,
      source: "HUBSPOT" as const,
      eventType: "deal.at_risk",
      severity: "CRITICAL" as const,
      title: `Deal at risk — ${deal.name} closes in ${daysToClose} days`,
      description: `Expected close in ${daysToClose} days but no activity in ${deal.daysSinceActivity} days. $${deal.amount.toLocaleString()} at stake.`,
      amount: deal.amount,
      entityId: deal.id,
      entityName: deal.name,
      entityUrl: `https://app.hubspot.com/contacts/deals/${deal.id}`,
      rawData: deal as any,
      fingerprint: fp,
    });
  }

  // Upsert all events
  for (const event of events) {
    await db.businessEvent.upsert({
      where: { fingerprint: event.fingerprint },
      update: { description: event.description },
      create: event,
    });
  }

  await db.integration.update({
    where: { id: integration.id },
    data: { lastSyncAt: new Date(), syncError: null },
  });
}

/** Build OAuth URL for HubSpot connect */
export function getHubSpotAuthUrl(orgId: string): string {
  const scopes = [
    "crm.objects.deals.read",
    "crm.objects.contacts.read",
    "crm.objects.companies.read",
  ].join(" ");

  const params = new URLSearchParams({
    client_id: process.env.HUBSPOT_CLIENT_ID!,
    redirect_uri: process.env.HUBSPOT_REDIRECT_URI!,
    scope: scopes,
    state: orgId,
  });

  return `https://app.hubspot.com/oauth/authorize?${params}`;
}
