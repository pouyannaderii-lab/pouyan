// src/lib/ai/briefing-engine.ts
// ─────────────────────────────────────────
// HELM AI BRIEFING ENGINE
// This is the core of Helm. Every night it:
// 1. Pulls all recent business events for an org
// 2. Loads the user's business baselines
// 3. Sends everything to Claude with a structured prompt
// 4. Claude reasons across all data and returns a ranked briefing
// 5. For each insight, Claude writes an action draft (email, etc.)
// ─────────────────────────────────────────

import Anthropic from "@anthropic-ai/sdk";
import { db } from "@/lib/db";
import type { BusinessEvent, BusinessBaseline, User } from "@prisma/client";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

// ─────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────

export interface BriefingInsight {
  order: number;
  severity: "CRITICAL" | "WARNING" | "INFO" | "POSITIVE";
  title: string;
  description: string;
  actionLabel: string | null;
  actionType: string | null;
  actionDraft: string | null;
  sourceEventId: string | null;
}

export interface GeneratedBriefing {
  headline: string;
  summary: string;
  healthScore: number;
  insights: BriefingInsight[];
}

// ─────────────────────────────────────────
// MAIN FUNCTION
// ─────────────────────────────────────────

/**
 * Generate a complete daily briefing for a user's organization
 * This is the function called by the nightly BullMQ worker
 */
export async function generateBriefing(
  orgId: string,
  user: User
): Promise<GeneratedBriefing> {
  // 1. Load recent events (last 72 hours) — not yet resolved
  const recentEvents = await db.businessEvent.findMany({
    where: {
      orgId,
      isResolved: false,
      occurredAt: {
        gte: new Date(Date.now() - 72 * 60 * 60 * 1000),
      },
    },
    orderBy: [{ severity: "asc" }, { occurredAt: "desc" }],
    take: 30, // cap to prevent huge prompts
  });

  // 2. Load business baselines
  const baselines = await db.businessBaseline.findMany({ where: { orgId } });
  const baselineMap = Object.fromEntries(baselines.map((b) => [b.metric, b.value]));

  // 3. Load past week of briefing feedback (to improve ranking)
  const recentFeedback = await db.briefingItem.findMany({
    where: {
      briefing: { orgId },
      userFeedback: { not: null },
      actionTakenAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
    },
    take: 20,
    select: { title: true, userFeedback: true, actionTaken: true },
  });

  if (recentEvents.length === 0) {
    return generateEmptyBriefing();
  }

  // 4. Build the prompt context
  const context = buildPromptContext(recentEvents, baselineMap, user, recentFeedback);

  // 5. Call Claude
  const briefingData = await callClaude(context, user);

  return briefingData;
}

// ─────────────────────────────────────────
// PROMPT BUILDER
// ─────────────────────────────────────────

function buildPromptContext(
  events: BusinessEvent[],
  baselines: Record<string, number>,
  user: User,
  feedback: Array<{ title: string; userFeedback: number | null; actionTaken: boolean }>
): string {
  const mrrFormatted = baselines.mrr_cents
    ? `$${(baselines.mrr_cents / 100).toLocaleString()}`
    : "unknown";

  const pipelineFormatted = baselines.pipeline_value
    ? `$${baselines.pipeline_value.toLocaleString()}`
    : "unknown";

  return `
BUSINESS CONTEXT:
- Owner: ${user.name}
- Current MRR: ${mrrFormatted}
- Pipeline value: ${pipelineFormatted}
- Avg deal cycle: ${baselines.avg_deal_cycle_days ? `${baselines.avg_deal_cycle_days} days` : "unknown"}

RECENT EVENTS REQUIRING ANALYSIS (last 72 hours):
${events
  .map(
    (e, i) => `
[Event ${i + 1}]
ID: ${e.id}
Source: ${e.source}
Type: ${e.eventType}
Severity: ${e.severity}
Title: ${e.title}
Description: ${e.description}
${e.amount ? `Amount: $${e.amount.toLocaleString()}` : ""}
${e.entityName ? `Entity: ${e.entityName}` : ""}
Occurred: ${e.occurredAt.toISOString()}
`
  )
  .join("\n---\n")}

USER ENGAGEMENT HISTORY (what they found useful recently):
${
  feedback.length > 0
    ? feedback
        .map(
          (f) =>
            `- "${f.title}" → ${f.userFeedback === 1 ? "👍 Found useful" : "👎 Not useful"}${f.actionTaken ? ", took action" : ""}`
        )
        .join("\n")
    : "No feedback history yet"
}

OWNER EMAIL STYLE SAMPLE (for drafting messages in their voice):
${user.emailStyleSample || "Professional, direct, concise. Friendly but business-focused."}
`;
}

// ─────────────────────────────────────────
// CLAUDE API CALL
// ─────────────────────────────────────────

async function callClaude(
  context: string,
  user: User
): Promise<GeneratedBriefing> {
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const systemPrompt = `You are Helm, an AI Chief of Staff for small business owners.
Your job is to analyze all available business data and generate a crisp, actionable daily briefing.

CORE PRINCIPLES:
1. PRIORITIZE ruthlessly — surface only what truly matters. Max 5 insights. Quality over quantity.
2. CONNECT DOTS across data sources. A cold email + a cold CRM deal = bigger signal than either alone.
3. BE SPECIFIC — use actual numbers, names, and days. Never be vague.
4. RECOMMEND concrete actions — the business owner should know exactly what to do next.
5. WRITE IN SECOND PERSON — address them directly as "you" and "your".
6. AVOID ALARM FATIGUE — only use CRITICAL for things that genuinely need action today.
7. ALWAYS include a POSITIVE insight if one exists (momentum matters for morale).

HEALTH SCORE FORMULA:
- Start at 70
- +10 for MRR growth > 10%
- -15 for any invoice > 45 days overdue
- -10 for any deal going cold > 14 days  
- -5 for failed charges
- +5 for closed deals this week
- Cap between 20-95

For each insight that has an action, write the FULL action draft (complete email, message text, etc.) in the owner's voice.`;

  const userPrompt = `Today is ${today}. Here is the business data for ${user.name}:

${context}

Generate a complete daily briefing as a JSON object with this exact structure:
{
  "headline": "One punchy sentence summarizing the day (e.g., '3 critical items need your attention today')",
  "summary": "2-3 sentence narrative overview of the business state. What's working, what's at risk.",
  "healthScore": <integer 20-95>,
  "insights": [
    {
      "order": 1,
      "severity": "CRITICAL|WARNING|INFO|POSITIVE",
      "title": "Short, specific title with real numbers",
      "description": "2-3 sentences with specific details, amounts, names, days",
      "actionLabel": "Action button label (e.g., 'Draft Email', 'Schedule 1:1') or null if no action",
      "actionType": "DRAFT_EMAIL|SCHEDULE_MEETING|SEND_INVOICE_REMINDER|VIEW_DEAL|VIEW_INVOICE|CUSTOM|null",
      "actionDraft": "COMPLETE draft text if actionType involves writing. Write the full email/message body. Or null.",
      "sourceEventId": "<event ID from the list above, or null>"
    }
  ]
}

Rules:
- Max 5 insights, min 1
- Order by urgency (1 = most urgent)
- Include a POSITIVE insight if the data supports it
- actionDraft should be the COMPLETE email body (not a summary) — write it as if you are the business owner
- Return ONLY valid JSON, no markdown, no explanation`;

  const response = await anthropic.messages.create({
    model: "claude-opus-4-6",
    max_tokens: 2000,
    system: systemPrompt,
    messages: [{ role: "user", content: userPrompt }],
  });

  const content = response.content[0];
  if (content.type !== "text") {
    throw new Error("Unexpected Claude response type");
  }

  // Parse JSON response — strip any accidental markdown
  const jsonText = content.text
    .replace(/```json\n?/g, "")
    .replace(/```\n?/g, "")
    .trim();

  const parsed = JSON.parse(jsonText) as GeneratedBriefing;

  // Validate
  if (!parsed.insights || !Array.isArray(parsed.insights)) {
    throw new Error("Invalid briefing structure from Claude");
  }

  return parsed;
}

// ─────────────────────────────────────────
// SAVE BRIEFING TO DB
// ─────────────────────────────────────────

export async function saveBriefing(
  orgId: string,
  userId: string,
  briefing: GeneratedBriefing,
  date: Date
): Promise<string> {
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);

  // Create or update briefing for today
  const saved = await db.briefing.upsert({
    where: {
      orgId_userId_date: {
        orgId,
        userId,
        date: startOfDay,
      },
    },
    update: {
      headline: briefing.headline,
      summary: briefing.summary,
      healthScore: briefing.healthScore,
    },
    create: {
      orgId,
      userId,
      date: startOfDay,
      headline: briefing.headline,
      summary: briefing.summary,
      healthScore: briefing.healthScore,
    },
  });

  // Delete old items and recreate
  await db.briefingItem.deleteMany({ where: { briefingId: saved.id } });

  await db.briefingItem.createMany({
    data: briefing.insights.map((insight) => ({
      briefingId: saved.id,
      eventId: insight.sourceEventId || null,
      order: insight.order,
      severity: insight.severity as any,
      title: insight.title,
      description: insight.description,
      actionLabel: insight.actionLabel,
      actionType: insight.actionType as any,
      actionDraft: insight.actionDraft,
    })),
  });

  return saved.id;
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────

function generateEmptyBriefing(): GeneratedBriefing {
  return {
    headline: "All clear — no urgent items today",
    summary:
      "Your business is running smoothly. No critical issues were detected in the last 72 hours. Helm will continue monitoring and alert you when action is needed.",
    healthScore: 82,
    insights: [
      {
        order: 1,
        severity: "POSITIVE",
        title: "No critical issues detected",
        description:
          "All your connected integrations are running normally. Revenue and pipeline look stable. Check back tomorrow for your next briefing.",
        actionLabel: null,
        actionType: null,
        actionDraft: null,
        sourceEventId: null,
      },
    ],
  };
}
