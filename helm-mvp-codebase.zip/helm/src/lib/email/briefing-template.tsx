// src/lib/email/briefing-template.tsx
// Beautiful HTML email template for the Helm daily briefing
// Uses @react-email/components for reliable cross-client rendering

import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Row,
  Column,
  Section,
  Text,
  Tailwind,
  Link,
} from "@react-email/components";
import * as React from "react";
import type { Briefing, BriefingItem } from "@prisma/client";

interface BriefingEmailProps {
  userName: string;
  briefing: Briefing & { items: BriefingItem[] };
  appUrl: string;
}

const SEVERITY_CONFIG = {
  CRITICAL: { emoji: "🔥", label: "Critical", color: "#EF4444", bg: "#FEF2F2", border: "#FECACA" },
  WARNING:  { emoji: "⚠️", label: "Warning",  color: "#F59E0B", bg: "#FFFBEB", border: "#FDE68A" },
  INFO:     { emoji: "📊", label: "Info",      color: "#3B82F6", bg: "#EFF6FF", border: "#BFDBFE" },
  POSITIVE: { emoji: "✅", label: "Good",      color: "#10B981", bg: "#ECFDF5", border: "#A7F3D0" },
};

export function BriefingEmail({ userName, briefing, appUrl }: BriefingEmailProps) {
  const firstName = userName.split(" ")[0];
  const today = new Date(briefing.date).toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  const criticalCount = briefing.items.filter((i) => i.severity === "CRITICAL").length;
  const previewText = criticalCount > 0
    ? `⚠️ ${criticalCount} critical item${criticalCount > 1 ? "s" : ""} need your attention today`
    : "Your Helm briefing is ready";

  const healthColor =
    briefing.healthScore >= 80 ? "#10B981" :
    briefing.healthScore >= 60 ? "#F59E0B" : "#EF4444";

  return (
    <Html>
      <Head />
      <Preview>{previewText}</Preview>
      <Tailwind>
        <Body style={{ backgroundColor: "#F9FAFB", fontFamily: "Georgia, serif" }}>

          {/* Header */}
          <Container style={{ maxWidth: "600px", margin: "0 auto" }}>
            <Section style={{
              background: "#080A0E",
              borderRadius: "12px 12px 0 0",
              padding: "28px 40px",
            }}>
              <Row>
                <Column>
                  <Text style={{ color: "#F5A623", fontSize: "20px", fontWeight: "bold", margin: 0, fontFamily: "Georgia, serif" }}>
                    Helm ✦
                  </Text>
                  <Text style={{ color: "#6B7280", fontSize: "12px", margin: "4px 0 0", fontFamily: "monospace" }}>
                    {today}
                  </Text>
                </Column>
                <Column align="right">
                  <div style={{
                    display: "inline-block",
                    background: "rgba(245,166,35,0.15)",
                    border: "1px solid rgba(245,166,35,0.3)",
                    borderRadius: "100px",
                    padding: "6px 16px",
                  }}>
                    <Text style={{ color: "#F5A623", fontSize: "12px", margin: 0, fontFamily: "monospace" }}>
                      Health: <strong>{briefing.healthScore}/100</strong>
                    </Text>
                  </div>
                </Column>
              </Row>
            </Section>

            {/* Main Content */}
            <Section style={{
              background: "#111827",
              padding: "36px 40px",
            }}>
              {/* Greeting */}
              <Text style={{ color: "#9CA3AF", fontSize: "14px", margin: "0 0 8px", fontFamily: "monospace" }}>
                Good morning, {firstName}.
              </Text>
              <Heading style={{
                color: "#F0EDE8",
                fontSize: "24px",
                fontWeight: "normal",
                lineHeight: "1.3",
                margin: "0 0 16px",
                fontFamily: "Georgia, serif",
              }}>
                {briefing.headline}
              </Heading>
              <Text style={{
                color: "#9CA3AF",
                fontSize: "14px",
                lineHeight: "1.7",
                margin: "0 0 32px",
                fontFamily: "Georgia, serif",
              }}>
                {briefing.summary}
              </Text>

              <Hr style={{ borderColor: "rgba(255,255,255,0.07)", margin: "0 0 28px" }} />

              {/* Insights */}
              {briefing.items.sort((a, b) => a.order - b.order).map((item, idx) => {
                const config = SEVERITY_CONFIG[item.severity as keyof typeof SEVERITY_CONFIG];
                return (
                  <Section key={item.id} style={{ marginBottom: "16px" }}>
                    <div style={{
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(255,255,255,0.07)",
                      borderLeft: `3px solid ${config.color}`,
                      borderRadius: "8px",
                      padding: "18px 20px",
                    }}>
                      <Row>
                        <Column style={{ width: "24px" }}>
                          <Text style={{ margin: 0, fontSize: "18px" }}>{config.emoji}</Text>
                        </Column>
                        <Column style={{ paddingLeft: "12px" }}>
                          <Text style={{
                            color: "#F0EDE8",
                            fontSize: "14px",
                            fontWeight: "bold",
                            margin: "0 0 6px",
                            fontFamily: "Georgia, serif",
                          }}>
                            {item.title}
                          </Text>
                          <Text style={{
                            color: "#9CA3AF",
                            fontSize: "13px",
                            lineHeight: "1.6",
                            margin: "0 0 12px",
                            fontFamily: "Georgia, serif",
                          }}>
                            {item.description}
                          </Text>
                          {item.actionLabel && (
                            <Button
                              href={`${appUrl}/dashboard?action=${item.id}`}
                              style={{
                                background: config.color,
                                color: "white",
                                fontSize: "12px",
                                fontWeight: "bold",
                                padding: "8px 16px",
                                borderRadius: "6px",
                                fontFamily: "sans-serif",
                                textDecoration: "none",
                              }}
                            >
                              {item.actionLabel} →
                            </Button>
                          )}
                        </Column>
                      </Row>
                    </div>
                  </Section>
                );
              })}

              <Hr style={{ borderColor: "rgba(255,255,255,0.07)", margin: "28px 0 24px" }} />

              {/* CTA */}
              <Section style={{ textAlign: "center" }}>
                <Button
                  href={`${appUrl}/dashboard`}
                  style={{
                    background: "#F5A623",
                    color: "#080A0E",
                    fontSize: "14px",
                    fontWeight: "bold",
                    padding: "14px 32px",
                    borderRadius: "6px",
                    fontFamily: "sans-serif",
                    textDecoration: "none",
                  }}
                >
                  Open Full Dashboard →
                </Button>
                <Text style={{ color: "#6B7280", fontSize: "12px", margin: "16px 0 0", fontFamily: "monospace" }}>
                  {briefing.items.length} insight{briefing.items.length !== 1 ? "s" : ""} · Business health: {briefing.healthScore}/100
                </Text>
              </Section>
            </Section>

            {/* Footer */}
            <Section style={{
              background: "#080A0E",
              borderRadius: "0 0 12px 12px",
              padding: "20px 40px",
              borderTop: "1px solid rgba(255,255,255,0.05)",
            }}>
              <Row>
                <Column>
                  <Text style={{ color: "#374151", fontSize: "11px", margin: 0, fontFamily: "monospace" }}>
                    © 2025 Helm Inc. · Your AI Chief of Staff
                  </Text>
                </Column>
                <Column align="right">
                  <Link href={`${appUrl}/settings`} style={{ color: "#6B7280", fontSize: "11px", textDecoration: "none", marginRight: "12px", fontFamily: "monospace" }}>
                    Settings
                  </Link>
                  <Link href={`${appUrl}/unsubscribe`} style={{ color: "#6B7280", fontSize: "11px", textDecoration: "none", fontFamily: "monospace" }}>
                    Unsubscribe
                  </Link>
                </Column>
              </Row>
            </Section>

          </Container>
        </Body>
      </Tailwind>
    </Html>
  );
}
