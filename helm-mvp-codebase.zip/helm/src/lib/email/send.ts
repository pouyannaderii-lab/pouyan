// src/lib/email/send.ts
// Resend email delivery — sends the daily briefing

import { Resend } from "resend";
import { render } from "@react-email/render";
import { BriefingEmail } from "./briefing-template";
import { db } from "@/lib/db";
import type { Briefing, BriefingItem, User } from "@prisma/client";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendBriefingEmail(
  user: User,
  briefing: Briefing & { items: BriefingItem[] }
): Promise<void> {
  const html = render(
    BriefingEmail({
      userName: user.name || user.email,
      briefing,
      appUrl: process.env.NEXT_PUBLIC_APP_URL!,
    })
  );

  const date = new Date(briefing.date).toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric",
  });

  const criticalCount = briefing.items.filter(
    (i) => i.severity === "CRITICAL"
  ).length;

  const subject =
    criticalCount > 0
      ? `⚠️ ${criticalCount} item${criticalCount > 1 ? "s" : ""} need your attention — ${date}`
      : `☀️ Your Helm briefing — ${date}`;

  const { data, error } = await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL!,
    to: user.email,
    subject,
    html,
    tags: [
      { name: "type", value: "daily-briefing" },
      { name: "org", value: briefing.orgId },
    ],
  });

  if (error) {
    throw new Error(`Failed to send briefing email: ${error.message}`);
  }

  // Mark email as sent
  await db.briefing.update({
    where: { id: briefing.id },
    data: { emailSentAt: new Date() },
  });

  console.log(`[email] Sent briefing to ${user.email}, id: ${data?.id}`);
}
