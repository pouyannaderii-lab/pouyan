# 🚢 Helm — AI Chief of Staff for SMBs

> One morning briefing. Everything that matters. Built on Next.js 14, Supabase, BullMQ, and Claude.

---

## 🗂 Project Structure

```
helm/
├── prisma/
│   └── schema.prisma          # Full database schema
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout
│   │   ├── dashboard/          # Main app UI
│   │   ├── connect/            # Integration connect page
│   │   ├── login/              # Auth pages
│   │   └── api/
│   │       ├── briefing/       # GET/POST/PATCH briefing
│   │       ├── integrations/
│   │       │   ├── gmail/      # OAuth flow
│   │       │   ├── stripe/     # OAuth flow
│   │       │   ├── quickbooks/ # OAuth flow
│   │       │   └── hubspot/    # OAuth flow
│   │       └── webhooks/
│   │           └── stripe/     # Subscription lifecycle
│   ├── lib/
│   │   ├── db.ts               # Prisma client singleton
│   │   ├── crypto.ts           # AES-256 token encryption
│   │   ├── supabase/           # Server + client Supabase clients
│   │   ├── ai/
│   │   │   └── briefing-engine.ts  # ⭐ Core AI engine (Claude)
│   │   ├── integrations/
│   │   │   ├── gmail.ts        # Gmail API — cold thread detection
│   │   │   ├── stripe.ts       # Stripe — MRR, overdue invoices
│   │   │   └── hubspot.ts      # HubSpot — cold deals, pipeline
│   │   └── email/
│   │       ├── briefing-template.tsx  # React Email template
│   │       └── send.ts         # Resend delivery
│   ├── workers/
│   │   └── nightly-briefing.ts # ⭐ BullMQ scheduler + workers
│   └── middleware.ts           # Auth protection
└── .env.example                # All required env vars
```

---

## 🚀 Setup — From Zero to Running

### 1. Prerequisites

```bash
node >= 18
npm >= 9
redis (local or Redis Cloud)
```

### 2. Clone & Install

```bash
git clone <your-repo>
cd helm
npm install
```

### 3. Set Up Environment Variables

```bash
cp .env.example .env.local
```

Fill in each value in `.env.local`. See the comments in the file for where to get each key.

### 4. Set Up Supabase (Database + Auth)

1. Create project at [supabase.com](https://supabase.com)
2. Copy your `DATABASE_URL`, `DIRECT_URL`, `NEXT_PUBLIC_SUPABASE_URL`, and keys
3. Enable Google OAuth in Supabase → Authentication → Providers

### 5. Push Database Schema

```bash
npx prisma generate
npx prisma db push
```

Verify tables were created:
```bash
npx prisma studio
```

### 6. Set Up Redis

**Local (for development):**
```bash
# Mac
brew install redis && brew services start redis

# Ubuntu
sudo apt install redis-server && sudo systemctl start redis
```

**Production:** Use Redis Cloud (free tier works for MVP)

### 7. Set Up OAuth Apps

#### Google (Gmail)
1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create project → Enable Gmail API
3. Create OAuth 2.0 credentials
4. Add authorized redirect URI: `http://localhost:3000/api/integrations/gmail/callback`
5. Copy Client ID + Secret to `.env.local`

#### HubSpot
1. Go to [developers.hubspot.com](https://developers.hubspot.com)
2. Create app → OAuth settings
3. Add scopes: `crm.objects.deals.read`, `crm.objects.contacts.read`
4. Add redirect URI: `http://localhost:3000/api/integrations/hubspot/callback`

#### Stripe (for user billing, NOT the integration)
1. Go to [dashboard.stripe.com/webhooks](https://dashboard.stripe.com/webhooks)
2. Add endpoint: `https://yourdomain.com/api/webhooks/stripe`
3. Select events: `customer.subscription.*`, `invoice.payment_*`

### 8. Set Up Resend (Email)

1. Create account at [resend.com](https://resend.com)
2. Add and verify your sending domain
3. Create API key → paste into `.env.local`

### 9. Set Up Anthropic (AI)

1. Get API key at [console.anthropic.com](https://console.anthropic.com)
2. Add to `.env.local`

### 10. Generate Encryption Key

```bash
# Generate a secure 32-byte key (64 hex chars)
openssl rand -hex 32
# Paste output into ENCRYPTION_KEY in .env.local
```

---

## 🏃 Running the App

### Terminal 1 — Next.js App
```bash
npm run dev
# → http://localhost:3000
```

### Terminal 2 — Background Workers
```bash
npm run worker:briefing
# Watches for briefing schedule + processes queues
```

---

## 🧪 Testing the Briefing Engine

Manually trigger a briefing for a user (useful for testing):

```bash
# Add this to a test script or API route during development
import { generateBriefing, saveBriefing } from "@/lib/ai/briefing-engine"
import { db } from "@/lib/db"

const user = await db.user.findFirst()
const briefing = await generateBriefing(user.orgId, user)
console.log(briefing)
```

Or hit the API:
```bash
# Trigger manual regeneration (must be logged in)
curl -X POST http://localhost:3000/api/briefing \
  -H "Cookie: <your-session-cookie>"
```

---

## 🚢 Deploying to Production

### Vercel (Next.js)
```bash
npm i -g vercel
vercel
# Add all env vars in Vercel dashboard → Settings → Environment Variables
```

### Railway (Workers + Redis)
1. Create Railway project
2. Add Node.js service → connect to your repo
3. Set start command: `npm run worker:briefing`
4. Add Redis service (built-in)
5. Copy Redis URL to env vars

### Cloudflare (DNS + WAF)
1. Point your domain's nameservers to Cloudflare
2. Enable WAF rules + rate limiting on `/api/*`

---

## 📊 Database: Key Tables

| Table | Purpose |
|-------|---------|
| `User` | Auth, preferences, briefing time/timezone |
| `Organization` | Plan, Stripe subscription, billing |
| `Integration` | OAuth tokens (encrypted), sync status |
| `BusinessEvent` | Normalized events from all integrations |
| `BusinessBaseline` | Historical averages for anomaly detection |
| `Briefing` | Daily briefing records |
| `BriefingItem` | Individual insights within a briefing |

---

## 🔑 Key Design Decisions

**Why Supabase?**
Row-level security gives us multi-tenant data isolation out of the box. Built-in OAuth handles Google login cleanly.

**Why BullMQ?**
We need timezone-aware scheduling (each user's 7am is different). BullMQ with Redis handles this elegantly with job deduplication.

**Why Claude for the AI engine?**
Long context window (can fit a full week of business events), best reasoning quality for connecting dots across data sources, tool use for structured JSON output.

**Why encrypt tokens in DB?**
Even with row-level security, if someone gets DB access, OAuth tokens should still be useless without the encryption key stored separately in env.

---

## 🗺 MVP Checklist

- [x] Database schema
- [x] Auth (Supabase + Google OAuth)
- [x] Gmail integration (cold thread detection)
- [x] Stripe integration (MRR, overdue invoices)
- [x] HubSpot integration (cold deals, pipeline)
- [x] AI briefing engine (Claude)
- [x] Nightly worker with BullMQ
- [x] Briefing email (React Email + Resend)
- [x] API routes (briefing CRUD)
- [x] Stripe webhooks (subscription lifecycle)
- [ ] Dashboard UI (see helm-dashboard.html for design)
- [ ] Onboarding flow
- [ ] Connect integrations page
- [ ] Stripe billing integration (checkout)
- [ ] QuickBooks integration
- [ ] Settings page

---

## 💰 Estimated Build Time

| Phase | Time | Cost |
|-------|------|------|
| Database + Auth | 2 days | - |
| 3 integrations (Gmail/Stripe/HubSpot) | 4 days | - |
| AI engine + workers | 3 days | - |
| Dashboard UI | 3 days | - |
| Email + polish | 2 days | - |
| **Total MVP** | **~14 dev days** | **$15–25K** |

---

*Built with ❤️ using Next.js 14, Supabase, BullMQ, Anthropic Claude, Resend, and Prisma.*
